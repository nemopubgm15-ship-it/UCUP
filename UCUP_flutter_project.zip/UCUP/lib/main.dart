import 'package:flutter/material.dart';

void main() => runApp(const UCUPApp());

const gold = Color(0xFFFFC107);
const bg = Color(0xFF061018);
const card = Color(0xFF0D1B25);
const muted = Color(0xFF91A4B2);

class UCUPApp extends StatelessWidget {
  const UCUPApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'UCUP',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const LanguagePage(),
    );
  }
}

class LanguagePage extends StatelessWidget {
  const LanguagePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Logo(),
              const SizedBox(height: 22),
              const Text('UCUP', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: gold)),
              const SizedBox(height: 8),
              const Text('PUBG UC earning demo', style: TextStyle(color: muted)),
              const SizedBox(height: 38),
              _lang(context, "O‘zbekcha"),
              _lang(context, 'Русский'),
              _lang(context, 'English'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _lang(BuildContext context, String name) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: SizedBox(
      width: double.infinity,
      child: FilledButton(
        style: FilledButton.styleFrom(backgroundColor: card, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)),
        onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginPage())),
        child: Text(name),
      ),
    ),
  );
}

class Logo extends StatelessWidget {
  const Logo({super.key});
  @override
  Widget build(BuildContext context) => Container(
    width: 82, height: 82,
    decoration: BoxDecoration(color: gold, borderRadius: BorderRadius.circular(24)),
    child: const Center(child: Text('U', style: TextStyle(color: bg, fontSize: 48, fontWeight: FontWeight.w900))),
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final user = TextEditingController();
  final pass = TextEditingController();

  @override
  void dispose() { user.dispose(); pass.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Kirish')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Logo(),
        const SizedBox(height: 24),
        TextField(controller: user, decoration: const InputDecoration(labelText: 'Telefon yoki Gmail', border: OutlineInputBorder())),
        const SizedBox(height: 14),
        TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'Parol', border: OutlineInputBorder())),
        const SizedBox(height: 18),
        FilledButton(
          onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomePage())),
          child: const Padding(padding: EdgeInsets.all(14), child: Text('Kirish')),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomePage())),
          icon: const Icon(Icons.login),
          label: const Text('Google orqali kirish'),
        ),
        const SizedBox(height: 22),
        const Text('Demo versiya: bu ekranda haqiqiy akkaunt autentifikatsiyasi ulanmagan.', textAlign: TextAlign.center, style: TextStyle(color: muted)),
      ],
    ),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  double balance = 15.0;
  int watched = 0;

  void earn() {
    if (watched >= 50) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bugungi demo limiti: 50 ta reklama.')));
      return;
    }
    setState(() { watched++; balance += 0.05; });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('+0.05 UC qo‘shildi')));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      Dashboard(balance: balance, watched: watched, onEarn: earn),
      EarnPage(balance: balance, watched: watched, onEarn: earn),
      const ReferralPage(),
      ProfilePage(balance: balance),
    ];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Bosh sahifa'),
          NavigationDestination(icon: Icon(Icons.play_circle_outline), selectedIcon: Icon(Icons.play_circle), label: 'Earn UC'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Taklif'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }
}

class Dashboard extends StatelessWidget {
  final double balance; final int watched; final VoidCallback onEarn;
  const Dashboard({super.key, required this.balance, required this.watched, required this.onEarn});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      Row(children: [const Logo(), const SizedBox(width: 14), const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Xush kelibsiz!', style: TextStyle(color: muted)), Text('UCUP', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: gold))])]),
      const SizedBox(height: 22),
      _balanceCard(),
      const SizedBox(height: 16),
      Card(color: card, child: ListTile(
        leading: const CircleAvatar(backgroundColor: gold, child: Icon(Icons.play_arrow, color: bg)),
        title: const Text('Reklama ko‘rib UC ishlang'),
        subtitle: Text('$watched / 50 bugun ko‘rildi'),
        trailing: const Icon(Icons.chevron_right),
        onTap: onEarn,
      )),
      const SizedBox(height: 16),
      const Text('Eslatma', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Bu hozircha demo ilova. Haqiqiy PUBG UC yetkazib berish uchun server va rasmiy integratsiya kerak.', style: TextStyle(color: muted)),
    ],
  );

  Widget _balanceCard() => Container(
    padding: const EdgeInsets.all(22),
    decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(24), border: Border.all(color: gold.withOpacity(.35))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Balans', style: TextStyle(color: muted)),
      const SizedBox(height: 6),
      Text('${balance.toStringAsFixed(2)} UC', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: gold)),
      const SizedBox(height: 14),
      const LinearProgressIndicator(value: .30, minHeight: 7),
    ]),
  );
}

class EarnPage extends StatelessWidget {
  final double balance; final int watched; final VoidCallback onEarn;
  const EarnPage({super.key, required this.balance, required this.watched, required this.onEarn});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('Earn UC', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      const Text('Reklama ko‘rib demo UC yig‘ing.', style: TextStyle(color: muted)),
      const SizedBox(height: 22),
      Card(color: card, child: Padding(padding: const EdgeInsets.all(22), child: Column(children: [
        const Icon(Icons.ondemand_video, size: 58, color: gold),
        const SizedBox(height: 14),
        const Text('+0.05 UC', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: gold)),
        const SizedBox(height: 8),
        Text('Bugun: $watched / 50'),
        const SizedBox(height: 18),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: onEarn, icon: const Icon(Icons.play_arrow), label: const Padding(padding: EdgeInsets.all(13), child: Text('Reklamani ko‘rish')))),
      ]))),
      const SizedBox(height: 18),
      Card(color: card, child: ListTile(leading: const Icon(Icons.account_balance_wallet, color: gold), title: const Text('Balans'), trailing: Text('${balance.toStringAsFixed(2)} UC'))),
    ],
  );
}

class ReferralPage extends StatelessWidget {
  const ReferralPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('Do‘stlarni taklif qiling', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 12),
      const Text('Har bir taklif uchun bonus tizimini keyinchalik server orqali ulash mumkin.', style: TextStyle(color: muted)),
      const SizedBox(height: 22),
      Card(color: card, child: const Padding(padding: EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Sizning referral kodingiz', style: TextStyle(color: muted)),
        SizedBox(height: 8),
        SelectableText('PLAYER007', style: TextStyle(fontSize: 25, color: gold, fontWeight: FontWeight.bold)),
        SizedBox(height: 14),
        SelectableText('https://ucup.app/ref/PLAYER007'),
      ]))),
    ],
  );
}

class ProfilePage extends StatelessWidget {
  final double balance;
  const ProfilePage({super.key, required this.balance});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Center(child: Logo()),
      const SizedBox(height: 12),
      const Center(child: Text('Player_007', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
      const Center(child: Text('PUBG ID: 5123456789', style: TextStyle(color: muted))),
      const SizedBox(height: 24),
      Card(color: card, child: Column(children: [
        ListTile(leading: const Icon(Icons.account_balance_wallet, color: gold), title: const Text('Balans'), trailing: Text('${balance.toStringAsFixed(2)} UC')),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.download), title: const Text('UC yechib olish'), onTap: () => _withdraw(context)),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.settings), title: const Text('Sozlamalar'), onTap: () {}),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.info_outline), title: const Text('Ilova haqida'), onTap: () => showAboutDialog(context: context, applicationName: 'UCUP', applicationVersion: '1.0.0 Demo')),
      ])),
    ],
  );

  void _withdraw(BuildContext context) => showDialog(context: context, builder: (_) => AlertDialog(
    title: const Text('UC yechib olish'),
    content: const Text('Bu demo versiya. Haqiqiy UC transferi hali ulanmagan.'),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Yopish'))],
  ));
}

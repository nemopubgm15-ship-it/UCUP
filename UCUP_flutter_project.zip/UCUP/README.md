# UCUP Flutter project

This package contains the UCUP demo app source and a Codemagic workflow.

## Build with Codemagic
1. Upload this folder to a GitHub repository.
2. In Codemagic, connect the GitHub repository.
3. Start the `ucup-android` workflow.
4. Download the generated release APK from build artifacts.

The workflow creates the standard Android folder automatically with `flutter create .` if it is missing.

## Important
This is a demo application. It does not actually deliver PUBG UC, authenticate real accounts, process payments, or connect to PUBG/KRAFTON services. Do not enter real passwords into the demo login.
